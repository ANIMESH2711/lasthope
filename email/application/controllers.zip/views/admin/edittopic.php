<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
	<!-- ============================================================== -->
	<!-- Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-themecolor">Subject</h3>
		</div>
		<div class="col-md-7 align-self-center">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="<?=base_url('Admin/Dashboard');?>">Home</a></li>
				<li class="breadcrumb-item">Topic List</li>
			</ol>
		</div>
		<div>
			<button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
		</div>
	</div>
	<!-- ============================================================== -->
	<!-- End Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<!-- ============================================================== -->
	<!-- Container fluid  -->
	<!-- ============================================================== -->
	<div class="container-fluid">
		<!-- ============================================================== -->
		<!-- Start Page Content -->
		<!-- ============================================================== -->
		<?= $this->lib->notification();?>
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body">
						<h4 class="card-title">Edit Topic</h4>
						<h6 class="card-subtitle">Just add <code>as your required</code></h6>
						<form class="form-material m-t-40" method="post" action="<?=base_url('Admin/EdittopicProcess');?>" enctype="multipart/form-data">
							<?php
							foreach ($rt as $r)
							{
								?>
								<div class="form-group">
									<label>Subject Code<span class="help"> e.g. "NCS-501"</span></label>
									<input name="CCode" type="text" class="form-control form-control-line" value="<?=$r->subjectcode;?>" readonly>
								</div>
								<div class="form-group">
									<label>Topic</label>
									<input name="Ctopic" type="datalist" class="form-control form-control-line" value="<?=$r->topic;?>">
								</div>
								

								
								<div class="form-group">
									<input onclick="return confirm('Are you sure to Update this Topic');" type="submit" value="Submit" class="btn btn-lg btn-danger"></div>
								<?php
							}
							?>
							<input type="hidden" name="id" value="<?=$r->id;?>">
						</form>
					</div>
				</div>

			</div>
		</div>

