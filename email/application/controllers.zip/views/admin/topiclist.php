<!---<html>
<head>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
      <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
      <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>            
      <link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />  
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
</head><body>-->

<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
	<!-- ============================================================== -->
	<!-- Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-themecolor">Topic</h3>
		</div>
		<div class="col-md-7 align-self-center">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="<?=base_url('Admin/Dashboard');?>">Home</a></li>
				<li class="breadcrumb-item">Topic List</li>
			</ol>
		</div>
		<div>
			<button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>

		</div>
	</div>
	<!-- ============================================================== -->
	<!-- End Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<!-- ============================================================== -->
	<!-- Container fluid  -->
	<!-- ============================================================== -->

			<div class="container-fluid" style="position: absolute;  ;right: 5px;height: top: px">
<a href="<?=base_url('admin/account');?>"  

style="position: absolute; right: 22px;bottom: 30px;"> <br> <b><b>My Account</b></b> </a>
    </div>
    	<div class="container-fluid">
		<html>
		    
		    
		    <body>
		<div style="position: absolute;  ;right: 19px;">
		    
		    

 <select id="select">
     <option value="#" selected>Login As</option>

     <option value="<?=base_url('faculty/dashboard');?>">Faculty</option>
     <option value="<?=base_url('supervisior/supervisior_dashboard');?>">Supervisior</option>
</select>
<script>
 $('#select').change(function(){ 
 window.location.href = $(this).val();
});
</script></div></div>



</body></html>


	
	
	
	
	<!-- ============================================================== -->




<!DOCTYPE html>
<html>
<title>buttons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>


<div class="container-fluid">
<!--a href="<?=base_url('admin/dashboard');?>" class="w3-button w3-blue"
		style="position: absolute; right: 29%;height:100px;text-align: center;"><b>
		<b>Dashboard<br></a>
<a href="<?=base_url('Admin/AddFSM');?>" class="btn btn-block btn-lg btn-danger col-2"> Add New </a>-->
<a href="<?=base_url('Admin/Addtopic');?>" class="w3-button w3-red" 
style="position: absolute; right: 69%;height:100px;text-align: center;">&nbsp<b><b><br>
Add New&nbsp</a>


<a href="<?=base_url('Admin/FacultyList/');?>" class="w3-button w3-blue" 
style="position: absolute; right: 57%; height:100px;text-align: center;">&nbsp<b><b><br>All Faculty</b></b>&nbsp</a>
<a href="<?=base_url('Admin/SubjectList');?>" class="w3-button w3-blue" 
style="position: absolute; right: 40%;height:100px;text-align: center;">&nbsp<b><b><br>
All Subject&nbsp</a>
	<a href="<?=base_url('Admin/SSList/');?>" class="w3-button w3-blue"
	style="position: absolute; right: 20%;height:100px;text-align: center;">&nbsp<b><b><br>All Supervisior&nbsp</a>
	
	
	
	
	<!--<a href="<?=base_url('Supervisior/RequestQuestion');?>" class="w3-button w3-blue"
		style="position: absolute; right: 29%;height:100px;text-align: center;"><b><b><br></a>
	<a href="<?=base_url('Supervisior/RequestQuestion');?>" class="w3-button w3-blue"
		style="position: absolute; right: 11%;height:100px;text-align: center;"><b><b><br>
		Question Selectection <br>For Allocation</a>-->


		<br><br><br><br>
</div>
</body>
</html><hr>

<!--

	<div class="container-fluid">
		<a href="<?=base_url('Admin/AddSubject');?>" class="btn btn-block btn-lg btn-danger col-2"> Add New </a>
		<!-- <button type="button" data-toggle="modal" data-target="#userModal" class="btn btn-info btn-lg">Add</button>-->


 <div id="userModal" class="modal fade">  
      <div class="modal-dialog">  
           <form method="post" id="user_form">  
                <div class="modal-content">  
                     <div class="modal-header"> 
                     <h4 class="modal-title style="position: absolute; height:100px;text-align: left;"><b><b>Add TOPIC</b><b></h4>  &nbsp 
                          <button type="button" class="close" data-dismiss="modal">&times;</button>  
                          
                     </div>  
                     <div>
         <table class="table table-bordered">  
                <tr>  
                     <th style="border : double;">ID</th>  
                     <th style="border : double;">Topic Name</th>  
                     
                </tr>  
           <?php  
           if($r > 0)  
           {  
                foreach($r as $row)  
                {  
           ?>  
                <tr>  
                     <td><?php echo $row->id; ?></td>  
                     <td><?php echo $row->topic; ?></td>  
                       
                </tr>  
           <?php       
                }  
           }  
           else  
           {  
           ?>  
                <tr>  
                     <td colspan="5">No Data Found</td>  
                </tr>  
           <?php  
           }  
           ?>  
           </table>  


</div>                              
                     <div class="modal-footer">  
                          
					  <form method="post" action="<?=base_url('Admin/Addtopicprocess');?>" enctype="multipart/form-data">
					  <label for="topic">Topic:</label><br>
					  <input type="text" id="topic" name="topic" class="form-control" />

					  <br><br>
					  <input type="submit" value="Submit">
					</form> 
                          </div>  
                </div>  
             
      </div>  
 </div> 

 <!-- 
 <script type="text/javascript" language="javascript" >  
 $(document).ready(function(){  
      var dataTable = $('#user_data').DataTable({  
           "processing":true,  
           "serverSide":true,  
           "order":[],  
           "ajax":{  
                url:"<?php echo base_url() . 'crud/fetch_user'; ?>",  
                type:"POST"  
           },  
           "columnDefs":[  
                {  
                     "targets":[0, 3, 4],  
                     "orderable":false,  
                },  
           ],  
      });  
      $(document).on('submit', '#user_form', function(event){  
           event.preventDefault();  
           var firstName = $('#first_name').val();  
           var lastName = $('#last_name').val();  
           
            
           if(firstName != '' && lastName != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url() . 'crud/user_action'?>",  
                     method:'POST',  
                     data:new FormData(this),  
                     contentType:false,  
                     processData:false,  
                     success:function(data)  
                     {  
                          alert(data);  
                          $('#user_form')[0].reset();  
                          $('#userModal').modal('hide');  
                          dataTable.ajax.reload();  
                     }  
                });  
           }  
           else  
           {  
                alert("Bother Fields are Required");  
           }  
      });  
 });  
 </script> --> 









<br /> 











	<div style="position:fixed;left:5px; bottom:1px;" >
		<a href="<?=base_url('Admin/AddSubject');?>" class="btn btn-block btn-lg btn-danger col-2"> New </a>
		<hr></div>
		<!-- ============================================================== -->
		<!-- Start Page Content -->
		<!-- ============================================================== -->
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body">
						<h4 class="card-title">Topic List</h4>
						<div class="table-responsive m-t-40">
							<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
								<thead>
								<tr>
									<th>S.no</th>
									<th>Subject Code</th>
									<th>Topic</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
								</thead>
								<tfoot>
								<tr>
									<th>S.no</th>
									<th>Subject Code</th>
									<th>Topic</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
								</tfoot>
								<tbody>
								<?php
								$i=1;
								foreach ($rs as $r){
									

								
									if($r->status==0)
									{
										$status = 'Enable';
										$btnStatus = 'Disable';
										$btnClass  = 'danger';
									}
									else{
										$status = 'Disable';
										$btnStatus = 'Enable';
										$btnClass  = 'success';
									}
									?>
									<tr>
										<td><?=$i;?></td>
										<td><?=$r->subjectcode;?></td>
										<td><?=$r->topic;?></td>
										
										<td><?=$status;?></td>
										<td><a  class="btn btn-primary" href="<?=base_url('Admin/edittopic/'.$r->id);?>">
												Edit.
											</a> |
											<a onclick="return confirm('Are you sure to <?=$btnStatus;?> this records');" class="btn btn-<?=$btnClass;?>" href="<?=base_url('Admin/Disable/m_Subject/'.$r->id.'/'.$r->status.'/SubjectList');?>">
												<?=$btnStatus;?>
											</a> | 
											
											
											</i>
											</a>
											</td>
									</tr>
									<?php
									$i++;
								}
								?>

								</tbody>
							</table>
						</div>
					</div>
				</div>

			</div>

			

		</div>
		<!-- ============================================================== -->
		<!-- End PAge Content -->
		<!-- ============================================================== -->
  <form method="post" action="<?=base_url('Admin/Addtopicprocess');?>" enctype="multipart/form-data">
					  <label for="topic">Topic:</label><br>
					  <input type="text" id="topic" name="topic" class="form-control" />

					  <br><br>
					  <input type="submit" value="Submit">
					</form> 
                          </div>  
                </div>  
           </form> 



