<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
	<!-- ============================================================== -->
	<!-- Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-themecolor">View Question</h3>
		</div>
		<div class="col-md-7 align-self-center">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="<?=base_url('Admin/Dashboard');?>">Home</a></li>
				<li class="breadcrumb-item">View Question</li>
			</ol>
		</div>
		<div>
			<button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
		</div>
	</div>
	<!-- ============================================================== -->
	<!-- End Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<!-- ============================================================== -->
	<!-- Container fluid  -->
	
		<div class="container-fluid" style="position: absolute;  ;right: 5px;height: top: px">
<a href="<?=base_url('admin/account');?>"  

style="position: absolute; right: 22px;bottom: 30px;"> <br> <b><b>My Account</b></b> </a>
    </div>
    	<div class="container-fluid">
		<html>
		    
		    
		    <body>
		<div style="position: absolute;  ;right: 19px;">
		    
		    

 <select id="select">
     <option value="#" selected>Login As</option>

     <option value="<?=base_url('faculty/dashboard');?>">Faculty</option>
     <option value="<?=base_url('supervisior/supervisior_dashboard');?>">Supervisior</option>
</select>
<script>
 $('#select').change(function(){ 
 window.location.href = $(this).val();
});
</script></div></div>



</body></html>
	
	
	
	
	<!-- ============================================================== -->
<hr>

	
		<!-- ============================================================== -->
		<!-- Start Page Content -->
		<!-- ============================================================== -->
		<div class="row">
			<div class="col-12"><div style="border-style: double;;">
				<div class="card">
					<div class="card-body">
						<h4 class="card-title">view Question</h4>
						
						<div class="table-responsive m-t-40">
							<table id="example23" class="display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
								
								<?php
								$i=1;
								foreach ($rs as $r)
								{
									if($r->status==0)
									{
										$status = 'pending';
										$btnStatus = 'Unapprove';
										$btnClass  = 'danger';
									}
									elseif ($r->status==1)
									{
										$status = 'Approve';
										$btnStatus = 'Approve';
										$btnClass  = 'success';
									} 
									elseif ($r->status==2)
									{
										$status = 'Rejected';
										$btnStatus = 'Approve';
										$btnClass  = 'success';
									} 
									   elseif ($r->status==3)
									{
										$status = 'Rejected & Qued';
										$btnStatus = 'Approve';
										$btnClass  = 'success';
									}  	
									    	
									  
									?>

									<div style="border: double;">
									    
									    <label>S.no :</label> 

									
										<?=$i;?>   


										&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

										<label>SUBJECT CODE :</label> 


										<?=$r->subjectcode;?>    

										&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp


									<label>Status :</label> 

										<?=$status;?></div>
										

											<div style="border: double;"><label>Question :</label> <br>



										<div><?=html_entity_decode("$r->name");?></div><br></div>

										<hr>


										<div style="border: double;"><label>Answer :</label> <br>

										<div><?=html_entity_decode("$r->about");?></div><br> </div>

										
										<td><!--<a  class="btn btn-primary" href="<?=base_url('Admin/EditFaculty/'.$r->id);?>">
												Edit
											</a>-->

										<!--<a  class="btn btn-primary" href="<?=base_url('Admin/ques_Disable/m_addques/'.$r->name.'/'.$r->status.'/queslist');?>">
												Approve
											</a> |
											<a onclick="return confirm('Are you sure to Reject this Question');" class="btn btn-primary" href="<?=base_url('Admin/ques_Disable/m_addques/'.$r->name.'/'.$r->status.'/queslist');?>">
												Reject</i>
											</a>-->
											
									<?php
									$i++;
								}
								?>

								</tbody>
							</table>
						</div>
					</div>
				</div>

			</div>
		</div></div>
		<!-- ============================================================== -->
		<!-- End PAge Content -->
		<!-- ============================================================== -->
