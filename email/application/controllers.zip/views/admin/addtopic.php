<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
	<!-- ============================================================== -->
	<!-- Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-themecolor">Add Topic</h3>
		</div>
		<div class="col-md-7 align-self-center">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="<?=base_url('Admin/Dashboard');?>">Home</a></li>
				<li class="breadcrumb-item">Add Topic</li>
			</ol>
		</div>
		<div>
			<button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
		</div>
	</div>
	<!-- ============================================================== -->
	<!-- End Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<!-- ============================================================== -->
	<!-- Container fluid  -->
	<!-- ============================================================== -->
	
		<div class="container-fluid" style="position: absolute;  ;right: 5px;height: top: px">
<a href="<?=base_url('admin/account');?>"  

style="position: absolute; right: 22px;bottom: 30px;"> <br> <b><b>My Account</b></b> </a>
    </div>
    	<div class="container-fluid">
		<html>
		    
		    
		    <body>
		<div style="position: absolute;  ;right: 19px;">
		    
		    

 <select id="select">
     <option value="#" selected>Login As</option>

     <option value="<?=base_url('faculty/dashboard');?>">Faculty</option>
     <option value="<?=base_url('supervisior/supervisior_dashboard');?>">Supervisior</option>
</select>
<script>
 $('#select').change(function(){ 
 window.location.href = $(this).val();
});
</script></div></div>



</body></html>
	
	
	
	<!-- ============================================================== -->




<!DOCTYPE html>
<html>
<title>buttons</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>


<div class="container-fluid">
<a href="<?=base_url('admin/dashboard');?>" class="w3-button w3-blue"
		style="position: absolute; right: 70%;height:100px;text-align: center;"><b>
		<b><br>Dashboard<br></a>
<!--<a href="<?=base_url('Admin/AddSubject');?>" class="w3-button w3-red" 
style="position: absolute; right: 69%;height:100px;text-align: center;">&nbsp<b><b><br>
Add New&nbsp</a>-->


<a href="<?=base_url('Admin/FacultyList/');?>" class="w3-button w3-blue" 
style="position: absolute; right: 57%; height:100px;text-align: center;">&nbsp<b><b><br>All Faculty</b></b>&nbsp</a>
<a href="<?=base_url('Admin/SubjectList');?>" class="w3-button w3-blue" 
style="position: absolute; right: 40%;height:100px;text-align: center;">&nbsp<b><b><br>
All Subject&nbsp</a>
	<a href="<?=base_url('Admin/SSList/');?>" class="w3-button w3-blue"
	style="position: absolute; right: 20%;height:100px;text-align: center;">&nbsp<b><b><br>All Supervisior&nbsp</a>
	
	
	
	
	<!--<a href="<?=base_url('Supervisior/RequestQuestion');?>" class="w3-button w3-blue"
		style="position: absolute; right: 29%;height:100px;text-align: center;"><b><b><br></a>
	<a href="<?=base_url('Supervisior/RequestQuestion');?>" class="w3-button w3-blue"
		style="position: absolute; right: 11%;height:100px;text-align: center;"><b><b><br>
		Question Selectection <br>For Allocation</a>-->


		<br><br><br><br>
</div>
</body>
</html><hr>



<script>
    $(function() {
        $("#contactForm").on('submit', function(e) {
            e.preventDefault();

            var contactForm = $(this);

            $.ajax({
                url: contactForm.attr('action'),
                type: 'post',
                data: contactForm.serialize(),
                success: function(response){
                    console.log(response);



      this.responseText;
                    if(response.status == 'success') {

                    	 alert("All AJAX requests completed");
                        $("#contactForm").hide();
                     //$('#contactForm')[0].reset(topic);




  
   



                    }

                    $("#message").html(response.message);
// $('#contactForm')[0].reset(topic);

                }
            });
        });
    });
</script>

		<!-- ============================================================== -->
		<!-- Start Page Content -->
		<!-- ============================================================== -->
		<!--<?  //= $this->lib->notification();?>-->
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body">
						<h4 class="card-title">Add Topic</h4>
						<h6 class="card-subtitle">Just add <code>as your required</code></h6>

						<!--<form class="form-material m-t-40" method="post" action="<?=base_url('Admin/Addtopicprocess');?>" enctype="multipart/form-data">-->

							<?php echo form_open('Admin/Addtopicprocess', array('id' => 'contactForm')) ?>


							<div class="form-group">
								<label>Subject List</label>
								<!--<select class="form-control" required name="S" id="S" onchange="document.getElementById('displayValue').value=this.options[this.selectedIndex].text; document.getElementById('idValue').value=this.options[this.selectedIndex].value;">
    									<option selected="">Select Subject</option>
									<?php
									foreach ($rs as $r)
									{
										?>
										<option value="<?=$r->subjectcode;?>"><?=$r->subjectcode;?></option>
										<?php
									}
									?>

								</select>
								 <input type="text" name="displayValue" id="contactForm" 
         placeholder="add/select a value" onfocus="this.select()"
         style="position:absolute;top:0px;left:0px;width:183px;width:180px\9;#width:180px;height:23px; height:21px\9;#height:18px;border:1px solid #556;"  >
  <input name="idValue" id="idValue" type="hidden">-->



  <label>Choose a Subject from this list:
<input list="S" class="form-control" name="S" /></label>
<datalist id="S">
 	
									<?php
									foreach ($rs as $r)
									{
										?>
										<option value="<?=$r->subjectcode;?>"><?=$r->subjectcode;?></option>
										<?php
									}
									?>
</datalist>-->




							</div><br><br>

							<div class="form-control">
								<label style="border: double;">- Topic :-</label>

				
					  <input type="text" id="topic" name="topic" class="form-control" />

					 
				         </div>  
                       </div>

							<div class="form-control">
								<button onclick="return confirm('Are you sure to upload this Topic');" type="submit" class="btn btn-info">Send Message</button>

								<!--<input type="submit" value="Submit" class="btn btn-lg btn-danger">
																		

									<div id="demo" style="visibility: hidden;"><h1>uploaded</h1></div>-->

								<?php echo form_close() ?>
							</div>
						
					</div>
				</div>

			</div>
		</div>


