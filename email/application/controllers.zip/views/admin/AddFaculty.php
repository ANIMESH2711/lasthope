<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
	<!-- ============================================================== -->
	<!-- Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<div class="row page-titles">
		<div class="col-md-5 align-self-center">
			<h3 class="text-themecolor">Faculty</h3>
		</div>
		<div class="col-md-7 align-self-center">
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="<?=base_url('Admin/Dashboard');?>">Home</a></li>
				<li class="breadcrumb-item">Add Faculty </li>
			</ol>
		</div>
		<div>
			<button class="right-side-toggle waves-effect waves-light btn-inverse btn btn-circle btn-sm pull-right m-l-10"><i class="ti-settings text-white"></i></button>
		</div>
	</div>
	<!-- ============================================================== -->
	<!-- End Bread crumb and right sidebar toggle -->
	<!-- ============================================================== -->
	<!-- ============================================================== -->
	<!-- Container fluid  -->
	
		<div class="container-fluid" style="position: absolute;  ;right: 5px;height: top: px">
<a href="<?=base_url('admin/account');?>"  

style="position: absolute; right: 22px;bottom: 30px;"> <br> <b><b>My Account</b></b> </a>
    </div>
    	<div class="container-fluid">
		<html>
		    
		    
		    <body>
		<div style="position: absolute;  ;right: 19px;">
		    
		    

 <select id="select">
     <option value="#" selected>Login As</option>

     <option value="<?=base_url('faculty/dashboard');?>">Faculty</option>
     <option value="<?=base_url('supervisior/supervisior_dashboard');?>">Supervisior</option>
</select>
<script>
 $('#select').change(function(){ 
 window.location.href = $(this).val();
});
</script></div></div>



</body></html><hr>
	
	
	
	
	<!-- ============================================================== -->
	<div class="container-fluid">
		<!-- ============================================================== -->
		<!-- Start Page Content -->
		<!-- ============================================================== -->
		<?= $this->lib->notification();?>
		<div class="row">
			<div class="col-12">
				<div class="card">
					<div class="card-body">
						<h4 class="card-title">Add Faculty</h4>
						<h6 class="card-subtitle">Just add <code>as your required</code></h6>
						<form class="form-material m-t-40" method="post" action="<?=base_url('Admin/AddFacultyProcess');?>" enctype="multipart/form-data">

							<div class="form-group">
								<label>Name<span class="help"> e.g. "Rakesh"</span></label>
								<input name="CName" type="text" class="form-control form-control-line" placeholder ="Some text value...">
							</div>
							
							<div class="form-group">
								<label>Password<span class="help"> (Choose a Strong Password)</span></label>
								<input name="password" type="password" class="form-control form-control-line" placeholder ="password...">
							</div>
							
							
							
							<div class="form-group">
								<label>Enrollment Id</label>
								<input name="Eid" type="text" class="form-control form-control-line" placeholder ="Some text value...">
							</div>
							<div class="form-group">
								<label>Email</label>
								<input name="Email" type="text" class="form-control form-control-line" placeholder ="Some text value...">
							</div>
							<div class="form-group">
								<label> Mobile</label>
								<input name="Mobile" type="text" class="form-control form-control-line" placeholder ="Some text value...">
							</div>
							<div class="form-group">
								<label> Address</label>
								<input name="Address" type="text" class="form-control form-control-line" placeholder ="Some text value...">
							</div>
							<div class="form-group">
								<label>Remarks</label>
								<textarea name="CAbout" class="form-control" rows="5"></textarea>
							</div>
							<div class="form-group">
								<input type="submit" value="Submit" class="btn btn-lg btn-danger"></div>
						</form>
					</div>
				</div>

			</div>
		</div>

